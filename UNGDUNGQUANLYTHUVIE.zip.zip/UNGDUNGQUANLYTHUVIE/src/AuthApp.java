import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.util.HashMap;
import java.util.Map;

public class AuthApp extends JFrame {

    // ─── Màu sắc & font ───────────────────────────────────────────
    static final Color BG_DARK      = new Color(15, 17, 26);
    static final Color BG_PANEL     = new Color(22, 26, 40);
    static final Color BG_INPUT     = new Color(30, 35, 55);
    static final Color ACCENT_BLUE  = new Color(79, 140, 255);
    static final Color ACCENT_TEAL  = new Color(29, 158, 117);
    static final Color TEXT_WHITE   = new Color(230, 235, 255);
    static final Color TEXT_MUTED   = new Color(120, 130, 160);
    static final Color BORDER_COLOR = new Color(50, 60, 90);
    static final Color SUCCESS      = new Color(39, 174, 96);
    static final Color DANGER       = new Color(220, 60, 60);
    static final Color ADMIN_COLOR  = new Color(220, 130, 50);

    static final Font FONT_TITLE    = new Font("Segoe UI", Font.BOLD, 26);
    static final Font FONT_LABEL    = new Font("Segoe UI", Font.PLAIN, 13);
    static final Font FONT_BOLD     = new Font("Segoe UI", Font.BOLD, 14);
    static final Font FONT_SMALL    = new Font("Segoe UI", Font.PLAIN, 12);
    static final Font FONT_INPUT    = new Font("Segoe UI", Font.PLAIN, 14);

    // ─── Dữ liệu giả lập ──────────────────────────────────────────
    static final Map<String, String[]> USERS = new HashMap<>();
    // key=username, value=[password, role, fullname, email]
    static {
        USERS.put("admin",   new String[]{"admin123",  "ADMIN", "Administrator",   "admin@system.vn"});
        USERS.put("manager", new String[]{"manager1",  "ADMIN", "Quản lý hệ thống","manager@system.vn"});
        USERS.put("user1",   new String[]{"user123",   "USER",  "Nguyễn Văn An",   "an@email.com"});
    }

    private JPanel mainPanel;
    private CardLayout cardLayout;

    public AuthApp() {
        setTitle("Hệ thống Quản lý Tài khoản");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(900, 600);
        setMinimumSize(new Dimension(860, 560));
        setLocationRelativeTo(null);
        setBackground(BG_DARK);

        cardLayout = new CardLayout();
        mainPanel  = new JPanel(cardLayout);
        mainPanel.setBackground(BG_DARK);

        mainPanel.add(buildLoginPanel(),    "LOGIN");
        mainPanel.add(buildRegisterPanel(), "REGISTER");

        add(mainPanel);
        cardLayout.show(mainPanel, "LOGIN");
        setVisible(true);
    }

    // ═══════════════════════════════════════════════════════════════
    //  ĐĂNG NHẬP
    // ═══════════════════════════════════════════════════════════════
    private JPanel buildLoginPanel() {
        JPanel root = new JPanel(new GridBagLayout());
        root.setBackground(BG_DARK);

        // ── left decoration ─────────────────────────────────────
        JPanel left = new GradientPanel();
        left.setPreferredSize(new Dimension(340, 600));
        left.setLayout(new GridBagLayout());
        addLeftContent(left, "ĐĂNG NHẬP", "Chào mừng trở lại!\nQuản trị viên & người dùng\nđăng nhập tại đây.", ACCENT_BLUE);

        // ── right form ──────────────────────────────────────────
        JPanel right = new JPanel();
        right.setBackground(BG_PANEL);
        right.setLayout(new BoxLayout(right, BoxLayout.Y_AXIS));
        right.setBorder(new EmptyBorder(50, 50, 50, 50));

        JLabel title = styledLabel("Đăng nhập", FONT_TITLE, TEXT_WHITE);
        title.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel subtitle = styledLabel("Vui lòng nhập thông tin tài khoản của bạn", FONT_SMALL, TEXT_MUTED);
        subtitle.setAlignmentX(Component.LEFT_ALIGNMENT);

        right.add(title);
        right.add(Box.createRigidArea(new Dimension(0, 6)));
        right.add(subtitle);
        right.add(Box.createRigidArea(new Dimension(0, 30)));

        // username
        right.add(fieldLabel("Tên đăng nhập"));
        right.add(Box.createRigidArea(new Dimension(0, 6)));
        JTextField txtUser = styledTextField("Nhập tên đăng nhập...");
        right.add(txtUser);
        right.add(Box.createRigidArea(new Dimension(0, 16)));

        // password
        right.add(fieldLabel("Mật khẩu"));
        right.add(Box.createRigidArea(new Dimension(0, 6)));
        JPasswordField txtPass = styledPassField("Nhập mật khẩu...");
        right.add(txtPass);
        right.add(Box.createRigidArea(new Dimension(0, 8)));

        // remember / forgot
        JPanel optRow = new JPanel(new BorderLayout());
        optRow.setBackground(BG_PANEL);
        optRow.setMaximumSize(new Dimension(9999, 24));
        JCheckBox remember = new JCheckBox("Ghi nhớ đăng nhập");
        styleCheckbox(remember);
        JLabel forgot = styledLabel("Quên mật khẩu?", FONT_SMALL, ACCENT_BLUE);
        forgot.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        optRow.add(remember, BorderLayout.WEST);
        optRow.add(forgot, BorderLayout.EAST);
        right.add(optRow);
        right.add(Box.createRigidArea(new Dimension(0, 24)));

        // message
        JLabel msgLabel = new JLabel(" ");
        msgLabel.setFont(FONT_SMALL);
        msgLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        msgLabel.setMaximumSize(new Dimension(9999, 22));
        right.add(msgLabel);
        right.add(Box.createRigidArea(new Dimension(0, 6)));

        // login button
        JButton btnLogin = new JButton("  Đăng nhập  →");
        styleButton(btnLogin, ACCENT_BLUE, Color.WHITE);
        btnLogin.addActionListener(e -> {
            String u = txtUser.getText().trim();
            String p = new String(txtPass.getPassword());
            if (u.isEmpty() || p.isEmpty()) {
                setMsg(msgLabel, "⚠  Vui lòng điền đầy đủ thông tin.", DANGER);
                return;
            }
            String[] info = USERS.get(u);
            if (info == null || !info[0].equals(p)) {
                setMsg(msgLabel, "✗  Tên đăng nhập hoặc mật khẩu không đúng.", DANGER);
                return;
            }
            openDashboard(u, info);
        });
        right.add(btnLogin);
        right.add(Box.createRigidArea(new Dimension(0, 20)));

        // divider
        right.add(divider("hoặc"));
        right.add(Box.createRigidArea(new Dimension(0, 16)));

        // go to register
        JPanel regRow = new JPanel(new FlowLayout(FlowLayout.CENTER, 4, 0));
        regRow.setBackground(BG_PANEL);
        regRow.setMaximumSize(new Dimension(9999, 28));
        regRow.add(styledLabel("Chưa có tài khoản?", FONT_SMALL, TEXT_MUTED));
        JLabel regLink = styledLabel("Đăng ký ngay", FONT_SMALL, ACCENT_TEAL);
        regLink.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        regLink.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) { cardLayout.show(mainPanel, "REGISTER"); }
        });
        regRow.add(regLink);
        right.add(regRow);

        // demo hint
        right.add(Box.createVerticalGlue());
        JTextArea hint = new JTextArea("Demo: admin/admin123  |  manager/manager1  |  user1/user123");
        hint.setEditable(false); hint.setLineWrap(true); hint.setWrapStyleWord(true);
        hint.setFont(FONT_SMALL); hint.setForeground(TEXT_MUTED);
        hint.setBackground(BG_INPUT);
        hint.setBorder(new CompoundBorder(
                new LineBorder(BORDER_COLOR, 1, true),
                new EmptyBorder(8, 10, 8, 10)
        ));
        hint.setMaximumSize(new Dimension(9999, 50));
        right.add(hint);

        // layout
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weighty = 1;
        gbc.weightx = 0; root.add(left, gbc);
        gbc.weightx = 1; root.add(right, gbc);
        return root;
    }

    // ═══════════════════════════════════════════════════════════════
    //  ĐĂNG KÝ (chỉ cho USER)
    // ═══════════════════════════════════════════════════════════════
    private JPanel buildRegisterPanel() {
        JPanel root = new JPanel(new GridBagLayout());
        root.setBackground(BG_DARK);

        // ── left decoration ─────────────────────────────────────
        JPanel left = new GradientPanel2();
        left.setPreferredSize(new Dimension(340, 600));
        left.setLayout(new GridBagLayout());
        addLeftContent(left, "ĐĂNG KÝ", "Tạo tài khoản mới\nhoàn toàn miễn phí.\nChỉ dành cho người dùng.", ACCENT_TEAL);

        // ── right form ──────────────────────────────────────────
        JPanel right = new JPanel();
        right.setBackground(BG_PANEL);
        right.setLayout(new BoxLayout(right, BoxLayout.Y_AXIS));
        right.setBorder(new EmptyBorder(36, 50, 36, 50));

        JLabel title = styledLabel("Tạo tài khoản", FONT_TITLE, TEXT_WHITE);
        title.setAlignmentX(Component.LEFT_ALIGNMENT);
        JLabel subtitle = styledLabel("Điền thông tin để tạo tài khoản người dùng mới", FONT_SMALL, TEXT_MUTED);
        subtitle.setAlignmentX(Component.LEFT_ALIGNMENT);

        // badge ROLE = USER only
        JLabel roleBadge = new JLabel("  ROLE: USER  ");
        roleBadge.setFont(new Font("Segoe UI", Font.BOLD, 11));
        roleBadge.setForeground(new Color(39, 184, 129));
        roleBadge.setBackground(new Color(20, 60, 45));
        roleBadge.setOpaque(true);
        roleBadge.setBorder(new CompoundBorder(
                new LineBorder(new Color(39, 184, 129), 1, true),
                new EmptyBorder(3, 8, 3, 8)
        ));
        roleBadge.setAlignmentX(Component.LEFT_ALIGNMENT);

        right.add(title);
        right.add(Box.createRigidArea(new Dimension(0, 4)));
        right.add(subtitle);
        right.add(Box.createRigidArea(new Dimension(0, 10)));
        right.add(roleBadge);
        right.add(Box.createRigidArea(new Dimension(0, 22)));

        // fields
        right.add(fieldLabel("Họ và tên *"));
        right.add(Box.createRigidArea(new Dimension(0, 5)));
        JTextField txtName = styledTextField("Nguyễn Văn A");
        right.add(txtName);
        right.add(Box.createRigidArea(new Dimension(0, 14)));

        right.add(fieldLabel("Email *"));
        right.add(Box.createRigidArea(new Dimension(0, 5)));
        JTextField txtEmail = styledTextField("example@email.com");
        right.add(txtEmail);
        right.add(Box.createRigidArea(new Dimension(0, 14)));

        // username & phone on same row
        JPanel row2 = new JPanel(new GridLayout(1, 2, 14, 0));
        row2.setBackground(BG_PANEL);
        row2.setMaximumSize(new Dimension(9999, 90));
        JPanel p1 = new JPanel(); p1.setBackground(BG_PANEL); p1.setLayout(new BoxLayout(p1, BoxLayout.Y_AXIS));
        p1.add(fieldLabel("Tên đăng nhập *")); p1.add(Box.createRigidArea(new Dimension(0, 5)));
        JTextField txtUser = styledTextField("username123"); p1.add(txtUser);
        JPanel p2 = new JPanel(); p2.setBackground(BG_PANEL); p2.setLayout(new BoxLayout(p2, BoxLayout.Y_AXIS));
        p2.add(fieldLabel("Số điện thoại")); p2.add(Box.createRigidArea(new Dimension(0, 5)));
        JTextField txtPhone = styledTextField("0912 345 678"); p2.add(txtPhone);
        row2.add(p1); row2.add(p2);
        right.add(row2);
        right.add(Box.createRigidArea(new Dimension(0, 14)));

        // password & confirm on same row
        JPanel row3 = new JPanel(new GridLayout(1, 2, 14, 0));
        row3.setBackground(BG_PANEL);
        row3.setMaximumSize(new Dimension(9999, 90));
        JPanel p3 = new JPanel(); p3.setBackground(BG_PANEL); p3.setLayout(new BoxLayout(p3, BoxLayout.Y_AXIS));
        p3.add(fieldLabel("Mật khẩu *")); p3.add(Box.createRigidArea(new Dimension(0, 5)));
        JPasswordField txtPass = styledPassField("Tối thiểu 6 ký tự"); p3.add(txtPass);
        JPanel p4 = new JPanel(); p4.setBackground(BG_PANEL); p4.setLayout(new BoxLayout(p4, BoxLayout.Y_AXIS));
        p4.add(fieldLabel("Xác nhận mật khẩu *")); p4.add(Box.createRigidArea(new Dimension(0, 5)));
        JPasswordField txtConf = styledPassField("Nhập lại mật khẩu"); p4.add(txtConf);
        row3.add(p3); row3.add(p4);
        right.add(row3);
        right.add(Box.createRigidArea(new Dimension(0, 10)));

        // terms
        JCheckBox terms = new JCheckBox("Tôi đồng ý với Điều khoản sử dụng và Chính sách bảo mật");
        styleCheckbox(terms);
        right.add(terms);
        right.add(Box.createRigidArea(new Dimension(0, 8)));

        // message
        JLabel msgLabel = new JLabel(" ");
        msgLabel.setFont(FONT_SMALL);
        msgLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        msgLabel.setMaximumSize(new Dimension(9999, 22));
        right.add(msgLabel);
        right.add(Box.createRigidArea(new Dimension(0, 6)));

        // register button
        JButton btnReg = new JButton("  Tạo tài khoản  →");
        styleButton(btnReg, ACCENT_TEAL, Color.WHITE);
        btnReg.addActionListener(e -> {
            String name  = txtName.getText().trim();
            String email = txtEmail.getText().trim();
            String uname = txtUser.getText().trim();
            String pass  = new String(txtPass.getPassword());
            String conf  = new String(txtConf.getPassword());

            if (name.isEmpty() || email.isEmpty() || uname.isEmpty() || pass.isEmpty()) {
                setMsg(msgLabel, "⚠  Vui lòng điền đầy đủ các trường bắt buộc (*).", DANGER); return;
            }
            if (!email.contains("@") || !email.contains(".")) {
                setMsg(msgLabel, "⚠  Địa chỉ email không hợp lệ.", DANGER); return;
            }
            if (pass.length() < 6) {
                setMsg(msgLabel, "⚠  Mật khẩu phải có ít nhất 6 ký tự.", DANGER); return;
            }
            if (!pass.equals(conf)) {
                setMsg(msgLabel, "✗  Mật khẩu xác nhận không khớp.", DANGER); return;
            }
            if (!terms.isSelected()) {
                setMsg(msgLabel, "⚠  Vui lòng đồng ý với điều khoản sử dụng.", DANGER); return;
            }
            if (USERS.containsKey(uname)) {
                setMsg(msgLabel, "✗  Tên đăng nhập đã tồn tại, vui lòng chọn tên khác.", DANGER); return;
            }
            // Lưu user mới
            USERS.put(uname, new String[]{pass, "USER", name, email});
            setMsg(msgLabel, "✓  Đăng ký thành công! Đang chuyển đến đăng nhập...", SUCCESS);
            Timer t = new Timer(1400, ev -> {
                clearRegister(txtName, txtEmail, txtUser, txtPhone, txtPass, txtConf, terms, msgLabel);
                cardLayout.show(mainPanel, "LOGIN");
            });
            t.setRepeats(false); t.start();
        });
        right.add(btnReg);
        right.add(Box.createRigidArea(new Dimension(0, 14)));

        // back to login
        JPanel backRow = new JPanel(new FlowLayout(FlowLayout.CENTER, 4, 0));
        backRow.setBackground(BG_PANEL);
        backRow.setMaximumSize(new Dimension(9999, 26));
        backRow.add(styledLabel("Đã có tài khoản?", FONT_SMALL, TEXT_MUTED));
        JLabel backLink = styledLabel("Đăng nhập", FONT_SMALL, ACCENT_BLUE);
        backLink.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        backLink.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) { cardLayout.show(mainPanel, "LOGIN"); }
        });
        backRow.add(backLink);
        right.add(backRow);

        // layout
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.BOTH; gbc.weighty = 1;
        gbc.weightx = 0; root.add(left, gbc);
        gbc.weightx = 1; root.add(right, gbc);
        return root;
    }

    // ═══════════════════════════════════════════════════════════════
    //  DASHBOARD (hiện sau login)
    // ═══════════════════════════════════════════════════════════════
    private void openDashboard(String username, String[] info) {
        boolean isAdmin = "ADMIN".equals(info[1]);
        JDialog dlg = new JDialog(this, "Dashboard — " + info[2], true);
        dlg.setSize(640, 460);
        dlg.setLocationRelativeTo(this);
        dlg.getContentPane().setBackground(BG_DARK);
        dlg.setLayout(new BorderLayout());

        // header
        JPanel header = new JPanel(new BorderLayout(16, 0));
        header.setBackground(isAdmin ? new Color(30, 22, 12) : new Color(15, 25, 40));
        header.setBorder(new EmptyBorder(20, 30, 20, 30));

        JLabel avatar = new JLabel(String.valueOf(info[2].charAt(0)), SwingConstants.CENTER);
        avatar.setFont(new Font("Segoe UI", Font.BOLD, 22));
        avatar.setForeground(isAdmin ? ADMIN_COLOR : ACCENT_BLUE);
        avatar.setBackground(isAdmin ? new Color(50, 35, 10) : new Color(20, 40, 75));
        avatar.setOpaque(true);
        avatar.setPreferredSize(new Dimension(52, 52));
        avatar.setBorder(BorderFactory.createLineBorder(isAdmin ? ADMIN_COLOR : ACCENT_BLUE, 2));

        JPanel nameArea = new JPanel();
        nameArea.setBackground(header.getBackground());
        nameArea.setLayout(new BoxLayout(nameArea, BoxLayout.Y_AXIS));

        JLabel nameLabel = new JLabel(info[2]);
        nameLabel.setFont(FONT_BOLD); nameLabel.setForeground(TEXT_WHITE);

        JLabel roleLabel = new JLabel(isAdmin ? "⬡ ADMINISTRATOR" : "● USER");
        roleLabel.setFont(FONT_SMALL);
        roleLabel.setForeground(isAdmin ? ADMIN_COLOR : ACCENT_TEAL);

        nameArea.add(nameLabel); nameArea.add(Box.createRigidArea(new Dimension(0, 4))); nameArea.add(roleLabel);
        header.add(avatar, BorderLayout.WEST);
        header.add(nameArea, BorderLayout.CENTER);

        JButton btnOut = new JButton("Đăng xuất");
        btnOut.setFont(FONT_SMALL); btnOut.setForeground(DANGER);
        btnOut.setBackground(new Color(50, 20, 20));
        btnOut.setBorder(new CompoundBorder(new LineBorder(DANGER, 1, true), new EmptyBorder(6, 14, 6, 14)));
        btnOut.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnOut.addActionListener(e -> dlg.dispose());
        header.add(btnOut, BorderLayout.EAST);

        // body
        JPanel body = new JPanel();
        body.setBackground(BG_PANEL);
        body.setLayout(new BoxLayout(body, BoxLayout.Y_AXIS));
        body.setBorder(new EmptyBorder(24, 30, 24, 30));

        body.add(styledLabel("Thông tin tài khoản", FONT_BOLD, TEXT_WHITE));
        body.add(Box.createRigidArea(new Dimension(0, 14)));

        body.add(infoRow("Tên đăng nhập", username));
        body.add(Box.createRigidArea(new Dimension(0, 8)));
        body.add(infoRow("Họ và tên", info[2]));
        body.add(Box.createRigidArea(new Dimension(0, 8)));
        body.add(infoRow("Email", info[3]));
        body.add(Box.createRigidArea(new Dimension(0, 8)));
        body.add(infoRow("Vai trò", info[1]));
        body.add(Box.createRigidArea(new Dimension(0, 24)));

        if (isAdmin) {
            body.add(styledLabel("Chức năng quản trị:", FONT_BOLD, ADMIN_COLOR));
            body.add(Box.createRigidArea(new Dimension(0, 10)));
            JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
            btnRow.setBackground(BG_PANEL);
            btnRow.setMaximumSize(new Dimension(9999, 44));
            for (String lbl : new String[]{"Quản lý Users", "Cài đặt hệ thống", "Báo cáo & Log"}) {
                JButton b = new JButton(lbl);
                b.setFont(FONT_SMALL); b.setForeground(ADMIN_COLOR);
                b.setBackground(new Color(45, 30, 10));
                b.setBorder(new CompoundBorder(new LineBorder(ADMIN_COLOR, 1, true), new EmptyBorder(6, 14, 6, 14)));
                b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
                b.addActionListener(e -> JOptionPane.showMessageDialog(dlg, "Chức năng đang phát triển.", "Thông báo", JOptionPane.INFORMATION_MESSAGE));
                btnRow.add(b);
            }
            body.add(btnRow);
        } else {
            body.add(styledLabel("Chức năng người dùng:", FONT_BOLD, ACCENT_TEAL));
            body.add(Box.createRigidArea(new Dimension(0, 10)));
            JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
            btnRow.setBackground(BG_PANEL);
            btnRow.setMaximumSize(new Dimension(9999, 44));
            for (String lbl : new String[]{"Hồ sơ của tôi", "Đổi mật khẩu", "Thông báo"}) {
                JButton b = new JButton(lbl);
                b.setFont(FONT_SMALL); b.setForeground(ACCENT_TEAL);
                b.setBackground(new Color(10, 40, 32));
                b.setBorder(new CompoundBorder(new LineBorder(ACCENT_TEAL, 1, true), new EmptyBorder(6, 14, 6, 14)));
                b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
                b.addActionListener(e -> JOptionPane.showMessageDialog(dlg, "Chức năng đang phát triển.", "Thông báo", JOptionPane.INFORMATION_MESSAGE));
                btnRow.add(b);
            }
            body.add(btnRow);
        }

        dlg.add(header, BorderLayout.NORTH);
        dlg.add(body, BorderLayout.CENTER);
        dlg.setVisible(true);
    }

    // ═══════════════════════════════════════════════════════════════
    //  HELPER METHODS
    // ═══════════════════════════════════════════════════════════════
    private JLabel styledLabel(String text, Font f, Color c) {
        JLabel l = new JLabel(text); l.setFont(f); l.setForeground(c); return l;
    }

    private JLabel fieldLabel(String text) {
        JLabel l = styledLabel(text, FONT_SMALL, TEXT_MUTED);
        l.setAlignmentX(Component.LEFT_ALIGNMENT); return l;
    }

    private JTextField styledTextField(String placeholder) {
        JTextField f = new JTextField();
        f.setFont(FONT_INPUT); f.setForeground(TEXT_WHITE);
        f.setBackground(BG_INPUT); f.setCaretColor(TEXT_WHITE);
        f.setBorder(new CompoundBorder(
                new LineBorder(BORDER_COLOR, 1, true),
                new EmptyBorder(9, 12, 9, 12)
        ));
        f.setMaximumSize(new Dimension(Integer.MAX_VALUE, 42));
        f.setAlignmentX(Component.LEFT_ALIGNMENT);
        // placeholder simulation
        f.setText(placeholder); f.setForeground(TEXT_MUTED);
        f.addFocusListener(new FocusAdapter() {
            public void focusGained(FocusEvent e) {
                if (f.getText().equals(placeholder)) { f.setText(""); f.setForeground(TEXT_WHITE); }
            }
            public void focusLost(FocusEvent e) {
                if (f.getText().isEmpty()) { f.setText(placeholder); f.setForeground(TEXT_MUTED); }
            }
        });
        return f;
    }

    private JPasswordField styledPassField(String placeholder) {
        JPasswordField f = new JPasswordField();
        f.setFont(FONT_INPUT); f.setForeground(TEXT_MUTED);
        f.setBackground(BG_INPUT); f.setCaretColor(TEXT_WHITE);
        f.setBorder(new CompoundBorder(
                new LineBorder(BORDER_COLOR, 1, true),
                new EmptyBorder(9, 12, 9, 12)
        ));
        f.setMaximumSize(new Dimension(Integer.MAX_VALUE, 42));
        f.setAlignmentX(Component.LEFT_ALIGNMENT);
        f.setEchoChar((char) 0); f.setText(placeholder);
        f.addFocusListener(new FocusAdapter() {
            public void focusGained(FocusEvent e) {
                if (String.valueOf(f.getPassword()).equals(placeholder)) {
                    f.setText(""); f.setEchoChar('●'); f.setForeground(TEXT_WHITE);
                }
            }
            public void focusLost(FocusEvent e) {
                if (f.getPassword().length == 0) {
                    f.setEchoChar((char) 0); f.setText(placeholder); f.setForeground(TEXT_MUTED);
                }
            }
        });
        return f;
    }

    private void styleButton(JButton b, Color bg, Color fg) {

        // màu gốc
        Color hover = bg.brighter();

        b.setFont(new Font("Segoe UI", Font.BOLD, 15));
        b.setForeground(fg);
        b.setBackground(bg);

        b.setFocusPainted(false);
        b.setBorderPainted(false);
        b.setContentAreaFilled(false);
        b.setOpaque(false);

        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        b.setAlignmentX(Component.LEFT_ALIGNMENT);
        b.setMaximumSize(new Dimension(Integer.MAX_VALUE, 48));

        // padding
        b.setBorder(new EmptyBorder(12, 24, 12, 24));

        // custom paint bo góc đẹp
        b.setUI(new javax.swing.plaf.basic.BasicButtonUI() {
            @Override
            public void paint(Graphics g, JComponent c) {

                Graphics2D g2 = (Graphics2D) g.create();

                g2.setRenderingHint(
                        RenderingHints.KEY_ANTIALIASING,
                        RenderingHints.VALUE_ANTIALIAS_ON
                );

                ButtonModel model = b.getModel();

                // hover effect
                if (model.isRollover()) {
                    g2.setColor(hover);
                } else {
                    g2.setColor(bg);
                }

                // nền bo góc
                g2.fillRoundRect(0, 0, c.getWidth(), c.getHeight(), 18, 18);

                // viền sáng
                g2.setColor(new Color(255, 255, 255, 40));
                g2.drawRoundRect(0, 0, c.getWidth()-1, c.getHeight()-1, 18, 18);

                g2.dispose();

                super.paint(g, c);
            }
        });

        // animation hover
        b.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                b.repaint();
            }

            public void mouseExited(MouseEvent e) {
                b.repaint();
            }
        });
    }

    private void styleCheckbox(JCheckBox c) {
        c.setFont(FONT_SMALL); c.setForeground(TEXT_MUTED); c.setBackground(BG_PANEL);
        c.setAlignmentX(Component.LEFT_ALIGNMENT);
        c.setMaximumSize(new Dimension(Integer.MAX_VALUE, 24));
    }

    private void setMsg(JLabel l, String msg, Color c) {
        l.setText(msg); l.setForeground(c);
    }

    private JPanel divider(String text) {
        JPanel p = new JPanel(new BorderLayout(8, 0));
        p.setBackground(BG_PANEL); p.setMaximumSize(new Dimension(9999, 24));
        JSeparator l = new JSeparator(); l.setForeground(BORDER_COLOR);
        JSeparator r = new JSeparator(); r.setForeground(BORDER_COLOR);
        JLabel lbl = styledLabel(text, FONT_SMALL, TEXT_MUTED);
        p.add(l, BorderLayout.WEST); p.add(lbl, BorderLayout.CENTER); p.add(r, BorderLayout.EAST);
        return p;
    }

    private JPanel infoRow(String key, String value) {
        JPanel p = new JPanel(new BorderLayout());
        p.setBackground(BG_INPUT);
        p.setBorder(new CompoundBorder(new LineBorder(BORDER_COLOR, 1, true), new EmptyBorder(8, 14, 8, 14)));
        p.setMaximumSize(new Dimension(9999, 40));
        p.add(styledLabel(key, FONT_SMALL, TEXT_MUTED), BorderLayout.WEST);
        p.add(styledLabel(value, FONT_SMALL, TEXT_WHITE), BorderLayout.EAST);
        return p;
    }

    private void addLeftContent(JPanel panel, String tag, String desc, Color accent) {
        JPanel inner = new JPanel();
        inner.setLayout(new BoxLayout(inner, BoxLayout.Y_AXIS));
        inner.setOpaque(false);
        inner.setBorder(new EmptyBorder(0, 34, 0, 34));

        JLabel tagLabel = new JLabel(tag);
        tagLabel.setFont(new Font("Segoe UI", Font.BOLD, 12));
        tagLabel.setForeground(accent);
        tagLabel.setBorder(new CompoundBorder(
                new LineBorder(accent, 1, true),
                new EmptyBorder(4, 10, 4, 10)
        ));
        tagLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel bigIcon = new JLabel(tag.equals("ĐĂNG NHẬP") ? "🔐" : "✨");
        bigIcon.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 52));
        bigIcon.setAlignmentX(Component.LEFT_ALIGNMENT);

        inner.add(bigIcon);
        inner.add(Box.createRigidArea(new Dimension(0, 18)));
        inner.add(tagLabel);
        inner.add(Box.createRigidArea(new Dimension(0, 16)));

        for (String line : desc.split("\n")) {
            JLabel l = new JLabel(line);
            l.setFont(new Font("Segoe UI", Font.PLAIN, 15));
            l.setForeground(new Color(180, 195, 230));
            l.setAlignmentX(Component.LEFT_ALIGNMENT);
            inner.add(l);
            inner.add(Box.createRigidArea(new Dimension(0, 4)));
        }

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0; gbc.gridy = 0; gbc.anchor = GridBagConstraints.WEST;
        gbc.insets = new Insets(0, 0, 0, 0);
        panel.add(inner, gbc);
    }

    private void clearRegister(JTextField n, JTextField e, JTextField u, JTextField ph,
                               JPasswordField p, JPasswordField c, JCheckBox t, JLabel msg) {
        n.setText(""); e.setText(""); u.setText(""); ph.setText("");
        p.setText(""); c.setText(""); t.setSelected(false); msg.setText(" ");
    }

    // ═══════════════════════════════════════════════════════════════
    //  GRADIENT PANELS
    // ═══════════════════════════════════════════════════════════════
    static class GradientPanel extends JPanel {
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g;
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            GradientPaint gp = new GradientPaint(0, 0, new Color(20, 40, 90),
                    getWidth(), getHeight(), new Color(10, 20, 60));
            g2.setPaint(gp); g2.fillRect(0, 0, getWidth(), getHeight());
            // decorative circles
            g2.setColor(new Color(79, 140, 255, 30));
            g2.fillOval(-60, -60, 220, 220);
            g2.setColor(new Color(79, 140, 255, 15));
            g2.fillOval(100, 300, 280, 280);
        }
    }

    static class GradientPanel2 extends JPanel {
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g;
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            GradientPaint gp = new GradientPaint(0, 0, new Color(10, 45, 38),
                    getWidth(), getHeight(), new Color(5, 25, 22));
            g2.setPaint(gp); g2.fillRect(0, 0, getWidth(), getHeight());
            g2.setColor(new Color(29, 158, 117, 30));
            g2.fillOval(-60, -60, 220, 220);
            g2.setColor(new Color(29, 158, 117, 15));
            g2.fillOval(80, 320, 300, 300);
        }
    }

    // ═══════════════════════════════════════════════════════════════
    //  MAIN
    // ═══════════════════════════════════════════════════════════════
    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignored) {}

        UIManager.put("Panel.background",      BG_DARK);
        UIManager.put("OptionPane.background", BG_PANEL);
        UIManager.put("OptionPane.messageForeground", TEXT_WHITE);

        SwingUtilities.invokeLater(AuthApp::new);
    }
}